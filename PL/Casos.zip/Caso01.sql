--
-- Caso de estudio 01
--
-- Alternativa 1
--

INSERT INTO payment
SELECT empno, sysdate, sal, comm
FROM emp;

--
-- Alternativa 2
--

DECLARE
  CURSOR cu_emp
  IS
    SELECT *
    FROM   emp;

BEGIN
  FOR recu_emp IN cu_emp LOOP
    INSERT INTO payment
    VALUES (recu_emp.empno, sysdate, recu_emp.sal, recu_emp.comm);
  END LOOP;

EXCEPTION
  WHEN Others THEN
    Dbms_Output.put_line(SQLCODE || ' - ' || SQLERRM);
END;
