--
-- Caso de estudio 02
--

DECLARE
  CURSOR cu_emp
  IS
    SELECT *
    FROM   emp;

  rango NUMBER;

BEGIN
  FOR recu_emp IN cu_emp LOOP
    INSERT INTO payment
    VALUES (recu_emp.empno, sysdate, recu_emp.sal, recu_emp.comm);

    SELECT sg.grade INTO rango
    FROM   salgrade sg
    WHERE  recu_emp.sal >= sg.losal AND recu_emp.sal <= sg.hisal;

    IF rango >= 4 THEN
      INSERT INTO logemp
      VALUES (sysdate, 'Empleado : ' || recu_emp.ename || ' con salario mayor en grango :' || rango || ' liquidador por : ' || USER);

    END IF;
  END LOOP;

EXCEPTION
  WHEN Others THEN
    Dbms_Output.put_line(SQLCODE || ' - ' || SQLERRM);
END;
