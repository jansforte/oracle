--
-- Caso 03
--
-- alternativa 1
--

DECLARE
  ret NUMBER;
  FUNCTION fn_execute (nombre VARCHAR2, codigo NUMBER) RETURN NUMBER 
  IS
    sql_str VARCHAR2(1000);
  BEGIN
    sql_str := 'UPDATE emp SET ename = '||''''||nombre||''''||'
                WHERE empno = '||codigo;    
    EXECUTE IMMEDIATE sql_str; 
    RETURN SQL%ROWCOUNT;
  END fn_execute ;
BEGIN
     ret := fn_execute('Devjoker',7654);
     dbms_output.put_line(TO_CHAR(ret));
END;

--
-- alternativa 2
--

DECLARE
  ret NUMBER;
  FUNCTION fn_execute (nombre VARCHAR2, codigo NUMBER) RETURN NUMBER 
  IS
    sql_str VARCHAR2(1000);
  BEGIN
    sql_str := 'UPDATE emp SET ename = :new_nombre 
                WHERE empno = :new_codigo';    
    EXECUTE IMMEDIATE sql_str USING nombre, codigo;   
    RETURN SQL%ROWCOUNT;
  END fn_execute ;
BEGIN
     ret := fn_execute('Devjoker',7654);
     dbms_output.put_line(TO_CHAR(ret));
END;
