--
-- Caso de estudio 04
--

CREATE OR REPLACE PROCEDURE pLiquNomi (finFechLiqu DATE DEFAULT SYSDATE)
/*
  Author : gogomez
  Date   : 27-may-2013
  Desc   : Funcion que liquida la nomina.
  Param
    finFechLiqui  : Fecha de liquidacion
*/
IS
  CURSOR cu_emp
  IS
    SELECT *
    FROM   emp;

  rango NUMBER;

BEGIN
  FOR recu_emp IN cu_emp LOOP
    INSERT INTO payment
    VALUES (recu_emp.empno, finFechLiqu, recu_emp.sal, recu_emp.comm);

    SELECT sg.grade INTO rango
    FROM   salgrade sg
    WHERE  recu_emp.sal >= sg.losal AND recu_emp.sal <= sg.hisal;

    IF rango >= 4 THEN
      INSERT INTO logemp
      VALUES (sysdate, 'Empleado : ' || recu_emp.ename || ' con salario mayor en grango :' || rango || ' liquidador por : ' || USER);

    END IF;
  END LOOP;

EXCEPTION
  WHEN Others THEN
    Dbms_Output.put_line(SQLCODE || ' - ' || SQLERRM);
END pLiquNomi;

-- Alternativa de llamado del procedimiento usando la fecha

BEGIN

  pLiquNomi (To_Date('31-05-2013','DD-MM-YYYY'));

--EXCEPTION
--  WHEN Others THEN
END;

-- Alternativa de llamado del procedimiento sin usar parametros

BEGIN

   pLiquNomi;

--EXCEPTION
--  WHEN Others THEN
END;
