--
-- Caso 06
--

--
-- Author
-- [name]
--
-- Date
--[Date]

-- Description
-- [text]
--

CREATE OR REPLACE PACKAGE servicios
IS

/*
  -- Declaraciones de tipos y registros p�blicas
  {[TYPE <TypeName> IS <Datatype>;]}

  -- Declaraciones de variables y constantes publicas
  -- Tambi�n podemos declarar cursores
  {[<ConstantName> CONSTANT <Datatype> := <valor>;]}
  {[<VariableName> <Datatype>;]}*/
  -- Declaraciones de procedimientos y funciones p�blicas

  PROCEDURE pActSal (p_deptno emp.deptno%TYPE,
                     p_incremento NUMBER);
END servicios;
/

CREATE OR REPLACE PACKAGE BODY servicios
IS

  /*
  -- Declaraciones de tipos y registros privados
  {[TYPE <TypeName> IS <Datatype>;]}

  -- Declaraciones de variables y constantes privadas
  -- Tambi�n podemos declarar cursores
  {[<ConstantName> CONSTANT <Datatype> := <valor>;]}
  {[<VariableName> <Datatype>;]}
  */
  -- Implementacion de procedimientos y funciones
  PROCEDURE pActSal(p_deptno emp.deptno%TYPE,
                    p_incremento NUMBER)
  IS
    CURSOR cu_emp (v_deptno emp.deptno%TYPE)
    IS
      SELECT *
      FROM   emp e
      WHERE  e.deptno = v_deptno;

    rango NUMBER;

  BEGIN
    FOR recu_emp IN cu_emp(p_deptno) LOOP

      SELECT sg.grade INTO rango
      FROM   salgrade sg
      WHERE  recu_emp.sal >= sg.losal AND recu_emp.sal <= sg.hisal;

      IF rango <> 2 THEN
        UPDATE emp
        SET    sal = sal * (1 + p_incremento)
        WHERE  empno = recu_emp.empno;
      END IF;

    END LOOP;
    
  END;
END servicios;
/


-- Ejemplo de llamado

BEGIN

  servicios.pActSal (30, 0.05);

--EXCEPTION
--  WHEN Others THEN
END;
