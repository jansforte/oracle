--
-- Caso 07
--

--
-- Author
--
-- Author
-- [name]
--
-- Date
--[Date]

-- Description
-- [text]
--

CREATE OR REPLACE PACKAGE servicios
IS

/*
  -- Declaraciones de tipos y registros p�blicas
  {[TYPE <TypeName> IS <Datatype>;]}

  -- Declaraciones de variables y constantes publicas
  -- Tambi�n podemos declarar cursores
  {[<ConstantName> CONSTANT <Datatype> := <valor>;]}
  {[<VariableName> <Datatype>;]}*/
  -- Declaraciones de procedimientos y funciones p�blicas
  /*
   * pActSal - Procedimiento que actualiza el vr del salario
   * Parametros
   *  p_deptno     - departamento a procesar
   *  p_incremento - porcentaje de incremento a aplicar en decimales
   */
  PROCEDURE pActSal (p_deptno emp.deptno%TYPE,
                     p_incremento NUMBER);

  /*
   * fGetSal - Funcion que retorna el salario. Es polimorfica
   * Parametros
   *  p_empno      - codigo del empleado
   */
  FUNCTION  fGetSal (p_empno emp.empno%TYPE) RETURN NUMBER;
  /*
   * fGetSal - Funcion que retorna el salario. Es polimorfica
   * Parametros
   *  p_ename      - nombre del empleado
   */
  FUNCTION  fGetSal (p_ename emp.ename%TYPE) RETURN NUMBER;

END servicios;
/

CREATE OR REPLACE PACKAGE BODY servicios
IS

  /*
  -- Declaraciones de tipos y registros privados
  {[TYPE <TypeName> IS <Datatype>;]}

  -- Declaraciones de variables y constantes privadas
  -- Tambi�n podemos declarar cursores
  {[<ConstantName> CONSTANT <Datatype> := <valor>;]}
  {[<VariableName> <Datatype>;]}
  */
  -- Implementacion de procedimientos y funciones
  PROCEDURE pActSal(p_deptno emp.deptno%TYPE,
                    p_incremento NUMBER)
  IS
    CURSOR cu_emp (v_deptno emp.deptno%TYPE)
    IS
      SELECT *
      FROM   emp e
      WHERE  e.deptno = v_deptno;

    rango NUMBER;

  BEGIN
    FOR recu_emp IN cu_emp(p_deptno) LOOP

      SELECT sg.grade INTO rango
      FROM   salgrade sg
      WHERE  recu_emp.sal >= sg.losal AND recu_emp.sal <= sg.hisal;

      IF rango <> 2 THEN
        UPDATE emp
        SET    sal = sal * (1 + p_incremento)
        WHERE  empno = recu_emp.empno;
      END IF;

    END LOOP;
    
  END pActSal;

  FUNCTION  fGetSal (p_empno emp.empno%TYPE) RETURN NUMBER
  IS
    salario NUMBER;
  BEGIN
    SELECT sal INTO salario
    FROM   emp e
    WHERE  e.empno = p_empno;

    RETURN salario;
  EXCEPTION
    WHEN No_Data_Found THEN
      RETURN -1;
    WHEN OTHERS THEN
      Dbms_Output.put_line(SQLCODE || ' - ' || SQLERRM);
      RETURN -1;
  END fGetSal;

  FUNCTION  fGetSal (p_ename emp.ename%TYPE) RETURN NUMBER
  IS
    salario NUMBER;
  BEGIN
    SELECT sal INTO salario
    FROM   emp e
    WHERE  e.ename = p_ename;

    RETURN salario;
  EXCEPTION
    WHEN No_Data_Found THEN
      RETURN -1;
    WHEN OTHERS THEN
      Dbms_Output.put_line(SQLCODE || ' - ' || SQLERRM);
      RETURN -1;
  END fGetSal;

END servicios;
/


-- Ejemplo de llamado

BEGIN

  Dbms_Output.put_line('Salario de 7782 : '||servicios.fGetSal (7782));

  Dbms_Output.put_line('Salario de CLARK : '||servicios.fGetSal ('CLARK'));


--EXCEPTION
--  WHEN Others THEN
END;
